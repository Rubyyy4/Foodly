import React from 'react'
import './Header.css'

const Header = () => {
  return (
    <div className='header'>
      <div className="header-contents">
        <h2>Order your favourite food here</h2>
        <p>Experience the art of fine dining from the comfort of your home. We curate a selection of premium restaurants offering exceptional dishes and unparalleled quality. Perfect for special occasions or a luxurious night in.</p>
        <button>View Menu</button>
      </div>
    </div>
  )
}

export default Header
